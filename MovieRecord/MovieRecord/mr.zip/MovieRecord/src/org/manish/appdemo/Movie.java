package org.manish.appdemo;

public class Movie {
	
	private int screenId;
	private String movieName;
	private int nFTicket;
	
	public int getScreenId() {
		return screenId;
	}
	public void setScreenId(int screenId) {
		this.screenId = screenId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public int getnFTicket() {
		return nFTicket;
	}
	public void setnFTicket(int nFTicket) {
		this.nFTicket = nFTicket;
	}

}
